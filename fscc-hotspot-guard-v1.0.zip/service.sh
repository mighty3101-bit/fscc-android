#!/system/bin/sh
MODDIR=${0%/*}

while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 2
done
sleep 3

rm -f /dev/fscc_allowed
IFACES="wlan2 swlan0 ap0 softap0"

for c in FSCC_GUARD_FWD FSCC_GUARD_IN; do
    while iptables -w -D FORWARD -j "$c" 2>/dev/null; do :; done
    while iptables -w -D INPUT -j "$c" 2>/dev/null; do :; done
    iptables -w -F "$c" 2>/dev/null
    iptables -w -X "$c" 2>/dev/null
done
for c in FSCC_GUARD_FWD6 FSCC_GUARD_IN6; do
    while ip6tables -w -D FORWARD -j "$c" 2>/dev/null; do :; done
    while ip6tables -w -D INPUT -j "$c" 2>/dev/null; do :; done
    ip6tables -w -F "$c" 2>/dev/null
    ip6tables -w -X "$c" 2>/dev/null
done

iptables -w -N FSCC_GUARD_FWD
iptables -w -N FSCC_GUARD_IN
ip6tables -w -N FSCC_GUARD_FWD6 2>/dev/null || true
ip6tables -w -N FSCC_GUARD_IN6 2>/dev/null || true

for IF in $IFACES; do
    iptables -w -A FSCC_GUARD_FWD -i "$IF" -j DROP
    iptables -w -A FSCC_GUARD_FWD -o "$IF" -j DROP
    iptables -w -A FSCC_GUARD_IN -i "$IF" -p udp --dport 53 -j DROP
    iptables -w -A FSCC_GUARD_IN -i "$IF" -p tcp --dport 53 -j DROP
    ip6tables -w -A FSCC_GUARD_FWD6 -i "$IF" -j DROP 2>/dev/null || true
    ip6tables -w -A FSCC_GUARD_FWD6 -o "$IF" -j DROP 2>/dev/null || true
    ip6tables -w -A FSCC_GUARD_IN6 -i "$IF" -p udp --dport 53 -j REJECT 2>/dev/null || true
    ip6tables -w -A FSCC_GUARD_IN6 -i "$IF" -p tcp --dport 53 -j REJECT 2>/dev/null || true
done

iptables -w -I FORWARD 1 -j FSCC_GUARD_FWD
iptables -w -I INPUT 1 -j FSCC_GUARD_IN
ip6tables -w -I FORWARD 1 -j FSCC_GUARD_FWD6 2>/dev/null || true
ip6tables -w -I INPUT 1 -j FSCC_GUARD_IN6 2>/dev/null || true

while true; do
    if [ ! -f /dev/fscc_allowed ]; then
        ACTIVE=0
        for IF in $IFACES; do
            if [ -d "/sys/class/net/$IF" ] && ip addr show dev "$IF" 2>/dev/null | grep -q "inet "; then
                ACTIVE=1
                break
            fi
        done
        if [ "$ACTIVE" = "1" ]; then
            if ! iptables -w -L FORWARD -n 2>/dev/null | sed -n "3p" | grep -q "FSCC_GUARD_FWD"; then
                iptables -w -D FORWARD -j FSCC_GUARD_FWD 2>/dev/null
                iptables -w -I FORWARD 1 -j FSCC_GUARD_FWD
            fi
            APK=$(pm path com.fscc.android 2>/dev/null | head -n1 | cut -d: -f2)
            if [ -n "$APK" ]; then
                CLASSPATH="$APK" app_process /system/bin com.fscc.android.HotspotCtl stop >/dev/null 2>&1
            fi
            cmd wifi stop-softap >/dev/null 2>&1
            sleep 2
        fi
    fi
    sleep 1
done
