ui_print "- Installation de FSCC Hotspot Guard v1.0..."
set_perm_recursive "$MODPATH" 0 0 0755 0755
